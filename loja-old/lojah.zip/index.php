<?php include("cabecalho.php"); ?>
        <h1>Bem vindo!</h1>
<?php include("rodape.php"); ?>