<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
	<meta charset="utf-8">
	<title>loja de produtos</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="loja.css">
</head>
<body>
	<div class="navbar navbar-inverse navbar-fixed-top"> 
		<div class="principal">
			<div class="navbar-header">
				<a href="index.php" class="navbar-brand">LOJA</a>
			</div>
			<div>
				<ul class="nav navbar-nav">
					<li><a href="produto-formulario.php">ADICIONA PRODUTO</a></li>
					<li><a href="produto-lista.php">LISTA</a></li>
					<li><a href="sobre.php">SOBRE</a></li>
				</ul>
			</div>		
		</div>
	</div>
	<div class="container">